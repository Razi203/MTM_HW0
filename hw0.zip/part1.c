#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

#define ERROR -1

int main();
int get_count();
int* get_array(int n);
int exp_handler(int x);


int main(){
    int n = get_count();
    if (n == ERROR) return 0;

    int* arr = get_array(n);
    if (!arr) return 0;
    int sum = 0;
    for (int i = 0; i < n; i++){
        sum += exp_handler(arr[i]);
    }
    printf("Total exponent sum is %d\n", sum);
    free(arr);
    return 0;
}


int get_count(){
    printf("Enter size of input:\n");
    int n = 0;
    if (scanf("%d", &n) != 1){
        printf("Invalid size\n");
        return ERROR;
    }
    if (n < 1){
        printf("Invalid size\n");
        return ERROR;
    }
    return n;
}


int* get_array(int n){
    printf("Enter numbers:\n");
    int temp;
    int* arr = (int*)malloc(n*sizeof(int));
    for (int i = 0; i < n; i++){
        if (scanf(" %d", &temp) != 1){
            free(arr);
            printf("Invalid number\n");
            return NULL;
        }
        arr[i] = temp;
    }
    return arr;
}


int exp_handler(int x){
    int i = 0, n = 1;
    while (n < x){
        n *= 2;
        i++;
    }
    if (n != x) return 0;
    printf("The number %d is a power of 2: %d = 2^%d\n", x, x, i);
    return i;    
}